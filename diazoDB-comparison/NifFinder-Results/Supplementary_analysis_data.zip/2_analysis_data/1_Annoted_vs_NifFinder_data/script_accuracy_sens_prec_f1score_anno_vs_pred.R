# Load annotation and prediction tables
annot <- read.csv("nif_annotations_table.txt", sep = "\t", header = TRUE)
pred <- read.csv("nifFinder_predicted_table.txt", sep = "\t", header = TRUE)

# Select only the columns corresponding to Nif types
nif_columns <- 3:(ncol(annot) - 1)
annot_nif <- annot[, nif_columns]
pred_nif <- pred[, nif_columns]

# Identify the occurrence of each Nif type (1 = present, 0 = absent)
annot_occur <- ifelse(annot_nif > 0, 1, 0)
pred_occur <- ifelse(pred_nif > 0, 1, 0)

# Define a function to calculate evaluation metrics per row (genome)
calc_metrics <- function(y_true, y_pred) {
  TP <- sum(y_true == 1 & y_pred == 1)
  TN <- sum(y_true == 0 & y_pred == 0)
  FP <- sum(y_true == 0 & y_pred == 1)
  FN <- sum(y_true == 1 & y_pred == 0)
  
  accuracy <- (TP + TN) / (TP + TN + FP + FN) * 100
  sensitivity <- ifelse((TP + FN) > 0, TP / (TP + FN) * 100, NA)
  precision <- ifelse((TP + FP) > 0, TP / (TP + FP) * 100, NA)
  f1 <- ifelse(!is.na(precision) & !is.na(sensitivity) & (precision + sensitivity) > 0,
               2 * (precision * sensitivity) / (precision + sensitivity),
               NA)
  
  return(c(accuracy, sensitivity, precision, f1))
}

# Apply the function to each genome
metrics <- t(mapply(calc_metrics, split(annot_occur, row(annot_occur)),
                    split(pred_occur, row(pred_occur))))

colnames(metrics) <- c("Accuracy", "Sensitivity", "Precision", "F1_score")

# Identify the most and least correctly classified Nif types per genome
most_accurate_nifs <- apply((annot_occur == pred_occur), 1, function(row) {
  colnames(annot_occur)[which(row == TRUE)]
})
least_accurate_nifs <- apply((annot_occur != pred_occur), 1, function(row) {
  colnames(annot_occur)[which(row == TRUE)]
})

# Create strings listing the most and least accurate Nifs for each genome
most_accurate_nifs_str <- sapply(most_accurate_nifs, function(nifs) {
  if (length(nifs) > 0) paste(nifs, collapse = ", ") else "None"
})
least_accurate_nifs_str <- sapply(least_accurate_nifs, function(nifs) {
  if (length(nifs) > 0) paste(nifs, collapse = ", ") else "None"
})

# Combine results into a single data frame
result <- cbind(
  annot[, 1:2],
  metrics,
  most_accurate_nifs = most_accurate_nifs_str,
  least_accurate_nifs = least_accurate_nifs_str
)

# Save results to a .csv file
write.csv(result, "nif_metrics_per_genome.csv", row.names = FALSE)

print("Analysis completed and results saved as 'nif_metrics_per_genome.csv'.")
