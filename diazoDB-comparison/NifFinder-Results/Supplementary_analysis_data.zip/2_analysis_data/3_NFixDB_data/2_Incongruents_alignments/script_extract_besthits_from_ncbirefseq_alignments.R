# Script to extract best matching alignment files (first line hits)

process_blast_file <- function(file) {
  lines <- readLines(file)
  
  query_idx <- grep("^Query #", lines)
  results <- data.frame(
    File = character(),
    Query = character(),
    Best_Hit_Line = character(),
    stringsAsFactors = FALSE
  )
  
  for (i in seq_along(query_idx)) {
    # Taking Query
    query_line <- lines[query_idx[i]]
    query <- sub("^Query #[0-9]+: ", "", query_line)
    query <- sub(" Query ID:.*", "", query)  #remove the snippet after ID
    
    # Find hits section
    seq_start <- grep("Sequences producing significant alignments:", lines)
    seq_start <- seq_start[seq_start > query_idx[i]]
    if (length(seq_start) == 0) next
    
    # Best hit = first line after header
    hit_line <- lines[seq_start[1] + 3]  # skip 2 because it has the header line
    
    results <- rbind(results, data.frame(
      File = basename(file),
      Query = query,
      Best_Hit_Line = hit_line,
      stringsAsFactors = FALSE
    ))
  }
  
  return(results)
}

# ---- Use ----
setwd("/2_Incongruents_alignments/")

files <- list.files(pattern = "*.txt")

all_results <- do.call(rbind, lapply(files, process_blast_file))

# Salvar CSV
write.csv(all_results, "best_hits_summary.csv", row.names = FALSE)

print(all_results)

