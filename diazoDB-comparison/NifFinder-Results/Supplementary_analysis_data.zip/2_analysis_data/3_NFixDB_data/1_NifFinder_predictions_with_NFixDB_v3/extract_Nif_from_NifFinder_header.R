#extract Nif name predicted by NifFinder from FASTA header
library(stringr)

# Função para processar o arquivo e criar a tabela
process_nif_predictions <- function(fasta_file) {
  # Ler o arquivo FASTA
  fasta_lines <- readLines(fasta_file)
  
  # Inicializar vetores para armazenar os resultados
  sequence_names <- character()
  nif_predictions <- character()
  
  # Processar cada linha do arquivo
  for (line in fasta_lines) {
    # Verificar se é uma linha de cabeçalho
    if (startsWith(line, ">")) {
      # Extrair o nome da sequência (até o primeiro espaço)
      seq_name <- str_extract(line, "^>[^\\s]+")
      
      # Extrair a predição do NifFinder (se presente)
      if (grepl("NifFinder=", line)) {
        nif_pred <- str_extract(line, "NifFinder=[^\\]]+")
        nif_pred <- gsub("NifFinder=", "", nif_pred)
      } else {
        nif_pred <- "Não predito"
      }
      
      # Adicionar aos vetores
      sequence_names <- c(sequence_names, seq_name)
      nif_predictions <- c(nif_predictions, nif_pred)
    }
  }
  
  # Criar data frame com os resultados
  results_df <- data.frame(
    Sequencia = sequence_names,
    Nif_Predito = nif_predictions,
    stringsAsFactors = FALSE
  )
  
  return(results_df)
}

# Uso da função
# Substitua "seu_arquivo.fasta" pelo caminho do seu arquivo
resultados <- process_nif_predictions("NifFinder_predition_final_nifH_12192023.faa")

# Visualizar os resultados
print(resultados)

# Salvar como CSV (opcional)
write.csv(resultados, "nif_predictions.csv", row.names = FALSE)

# Análise resumida
cat("\nResumo das predições:\n")
print(table(resultados$Nif_Predito))